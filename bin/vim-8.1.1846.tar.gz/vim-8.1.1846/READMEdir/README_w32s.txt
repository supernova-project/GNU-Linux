README_w32s.txt for version 8.1 of Vim: Vi IMproved.

This archive contains the gvim.exe that was specifically compiled for use in
the Win32s subsystem in MS-Windows 3.1 and 3.11.

Also see the README_bindos.txt, README_dos.txt and README.txt files.

Be careful not to overwrite the Win32s gvim.exe with the another gvim.exe when
unpacking another binary archive!  Check the output of ":version":
	Win32s - "MS-Windows 16/32 bit GUI version"
	 Win32 - "MS-Windows 32 bit GUI version"
Win32 with OLE - "MS-Windows 32 bit GUI version with OLE support"

For further information, type this inside Vim:
	:help win32s
